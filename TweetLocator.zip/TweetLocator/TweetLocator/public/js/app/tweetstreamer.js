     // =================== Browser side Stuff ===================

     // =================== Initialize Google Maps ===================
    
     var map;
     function initialize() {
            var myLatlng = new google.maps.LatLng(-25.363882,131.044922);
            var mapOptions = {
              center: new google.maps.LatLng(-34.397, 150.644),
              zoom: 2,
              mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("map-canvas"),mapOptions);
    }

    // =================== Remove Markers when new search ===================

    var markers = [];

    // Deletes all markers in the array by removing references to them.
    function deleteMarkers() {
        clearMarkers();
        markers = [];
    }

    // Removes the markers from the map, but keeps them in the array.
    function clearMarkers() {
        setAllMap(null);
    }

    function setAllMap(map) {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(map);
        }
    }


// =================== Document.Ready ===================

    
$(document).ready(function () {

    var socket = io.connect('http://localhost:3000');
    
    // =================== Gezocht naar alles ( example or #Example ) ===================
    
    $("#searchb").click(function () {
        
        deleteMarkers();
        
        var search = document.getElementById('search').value;
        
        if (search.trim().length === 0) {
            alert('Cannot submit an empty search.');
            return;
        } else {
            alert("Query " + search + " send \n" + "You should get tweets bouncing shortly");
            
            socket.emit('search', { s : search });
        }        
    });
    
    
    // =================== Wanneer Tweet werd opgehaald van Twitter ===================

    socket.on('tweet', function (tweet) {
        console.log(tweet);
        var tweetLatLon = new google.maps.LatLng(tweet.lat, tweet.lon);
        
        // =================== InfoText met Tweet ===================
            var infoWindowText = '<div id="content">' + 
                                 '<div id="bodyContent">' + 
                                 '<img src=' + tweet.profileImage + ' /></br>' + 
                                 '<a href="' + 'https://twitter.com/' + tweet.screen_name + '" target="_blank">' + '@' + tweet.screen_name + '</a></br>' +
                                 tweet.text +'</div>' + '</div>';
            
            var infowindow = new google.maps.InfoWindow({
                     content: infoWindowText,
                     maxWidth: 200
            });
        
        // =================== Google Maps Marker ===================

            var marker = new google.maps.Marker({
                            position: tweetLatLon,
                            map: map,
                            title: '@' + tweet.user,
                            animation: google.maps.Animation.DROP,
                            icon: "/images/twitter-bird-16x16.png"
        });
        
            markers.push(marker);
            
            google.maps.event.addListener(marker, 'click', function() {
                    infowindow.open(map,marker);
            });
            
             
            $('#tweetcount').html(tweet.count);             
            $('#failed-lookups').html(tweet.failedLookUps);             
	        
             

        });
            google.maps.event.addDomListener(window, 'load', initialize);
   });    

