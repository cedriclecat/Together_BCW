  
  // =================== Module dependencies ===================

  var express = require('express');
  var app = express();
  var server = require('http').createServer(app);
  var io = require('socket.io').listen(server);

  var mongoose = require('mongoose');
  var passport = require('passport');

  var bodyParser = require('body-parser');
  var methodOverride = require('method-override');
  var cookieParser = require('cookie-parser');
  var session = require('express-session');
  var sentiment = require('sentiment');
  var stylus = require('stylus');
  var domain = require('domain');

  // =================== Listen to Server ===================
var port = process.env.PORT || 3000;
  server.listen(3000);

  // =================== Winston Logger ===================

  var winston = require('winston');
  var logger = new (winston.Logger)({
      transports: [new (winston.transports.Console)({ level: 'debug' })]
  })

  /* Stylus compile */
  function compile(str, path) {
     return stylus(str)
    .set('filename', path)
    .use(nib())
}

  //=================== Domain ===================

var d = domain.create();
// Domain emits 'error' when it's given an unhandled error��
d.on('error', function (err) {
    console.log(err.stack);
 // Our handler should deal with the error in an appropriate way
});

// Enter this domain
d.run(function () {
    // If an un-handled error originates from here, process.domain will handle it
    console.log(process.domain === d); // true
});

// =================== App use ===================

  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(bodyParser.json());
  app.use(methodOverride()); 					
  app.use(cookieParser());
  
  app.use(express.static(__dirname + '/public'))
  app.use(stylus.middleware(
    { src: __dirname + '/public'
      , compile: compile
    }
  ))
  app.set('views', __dirname + '/views')
  app.set('view engine', 'jade')

  

  // configuration ===============================================================

 require("./config/ConnectDB.js");
 // mongoose.connect(connectDB); // connect to our database

  // Passport ===============================================================

  require('./config/Passport.js')(passport); // pass passport for configuration

  app.use(session({ secret: 'ilovescotchscotchyscotchscotch' }));
  app.use(passport.initialize());
  app.use(passport.session()); // persistent login sessions

  // =================== Routes ===================

  require('./routes/routes.js')(app, passport);

  // =================== Server Socket ===================

  var TwitterEventStreamer = require('./twitter/twittereventstreamer.js');
  var Geocoder = require('./geocoder/geocoder.js');
 
  
  var tes;
  var geocoder;

  io.sockets.on('connection', function (socket) {

    
    socket.on('search', function (data) {
        var search = data.s;
        
        tes = undefined;
        geocoder = undefined;
        
        tes = new TwitterEventStreamer();
        geocoder = new Geocoder();

        tes.stream(search);
        
        tweetcounter = 0;

        tes.on('tweet', function (tweet) {
            
            
            ++tweetcounter;
            logger.debug('Tweet [' + tweetcounter + '] received from ' + tweet.user.name + ',' + 
                                   tweet.user.location);
            
            sentiment(tweet.text, function (err, results) {
                
                
                geocoder.geocode(tweet.user.location, function (err, geodata) {
                    if (!err) {
                        logger.debug('Tweet [' + tweetcounter + '] received from ' + tweet.user.name + ',' + 
                                     tweet.user.location +  
                                     ' Lat :' + geodata.lat + 
                                     ' Lon :' + geodata.lon);
                        if (socket !== null) {
                            socket.emit('tweet', {
                                user : tweet.user.name , 
                                screen_name : tweet.user.screen_name,
                                text: tweet.text.replace(/((http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?)/g, '<a href="$1">$1</a>')
                                                .replace(/(@([A-Za-z0-9_]+))/g, '<a href="https://twitter.com/$2">$1</a>')
                                                .replace(/(\#([A-Za-z0-9_]+))/g, '<a href="https://twitter.com/search?q=%23$2&src=hash">$1</a>'),
                                lat: geodata.lat ,
                                profileImage : tweet.user.profile_image_url,
                                lon: geodata.lon , count : tweetcounter
                            });
                            
                        }
                    } else {
                        logger.debug('Could not resolve location for ' + tweet.user.location 
                                               + ' error was this %j', err);
                        
                    }
                });
            });
        });
  

    });
  });
  