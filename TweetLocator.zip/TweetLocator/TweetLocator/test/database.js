﻿'use strict';

var should = require("should");
var mongoose = require('mongoose');
var request = require('superagent');
var user1 = request.agent();

var config = require("../config/ConnectDB");
var dbUrl = "mongodb://localhost/usersDB"
var User = require('../app/models/user');

var db;

// ================ Test Database Connection + Login + Signup ====================

describe('User', function () {
    
    before(function (done) {
        db = mongoose.connect(dbUrl);
        done();
    });
    
    after(function (done) {
        mongoose.connection.close()
        done();
    });
    
    beforeEach(function (done) {
        var user = new User({
            
            local :{
                email: 'bruce@wayne.inc',
                password: 'batman'
            }
        });
        
        user.save(function (err, user) {
            if (err) console.log('error' + err.message);
            else console.log('no error');
            
            done();
        });
    });
    
    it('find a user by username', function (done) {
        User.findOne({ 'local.email': 'bruce@wayne.inc' }, function (err, user) {
            user.local.email.should.eql('bruce@wayne.inc');
            console.log("email: ", user.local.email)
            done();
        });
    });
    
    it('login with a user', function (done) {
        user1
          .post('http://localhost:3000/login')
          .send({ user: 'bruce@wayne.inc', password: 'batman' })
          .end(function (err, res) {
            // user1 will manage its own cookies
            // res.redirects contains an Array of redirects
            done();
        });
    });
    
    it('signup with a user', function (done) { 
        user1
          .post('http://localhost:3000/signup')
          .send({ user: 'hunter@hunterloftis.com', password: 'password' })
          .end(function (err, res) {
            // user1 will manage its own cookies
            // res.redirects contains an Array of redirects
            done();
        });
    });
       
    afterEach(function (done) {
        User.remove({ 'local.email': 'bruce@wayne.inc' });
        User.remove({ 'local.email': 'hunter@hunterloftis.com' }, function () {
            done();
        });
    });
});


