    // =================== Werken met NTwitter Module ===================
    
    sys = require('sys');
    events = require('events');
    
    require('./credentials');

    var twitter = require('ntwitter');

    var str;

    // =================== Main Function ===================
    
    function TwitterEventStreamer() {
        events.EventEmitter.call(this);
    }

    sys.inherits(TwitterEventStreamer, events.EventEmitter);

    // =================== Stream ===================

    TwitterEventStreamer.prototype.stream = function(keyword) {
        var self = this;
        //var hashtag = "#" + keyword;
        var twitterCredentials = new TwitterCredentials(); 
        var twit = new twitter(twitterCredentials.getSecrets());

        counter = 0;
             
    twit.stream('statuses/filter', { track: keyword }, function (stream) {
        str = stream;
        console.log(stream);
                  stream.on('data', function(tweet) {
                        self.emit('tweet', tweet);
                  });
                  
                  stream.on('error', function(error,statusCode) {
                        console.log('Error was this %j', error);
                        console.log('Error was this ' + statusCode);
                        self.emit('error','Error occured on Twitter maybe?');

                });
                stream.on('destroy', function (response) {
                // Handle a 'silent' disconnection from Twitter, no end/error event fired
                });
                // LIMIT
               setTimeout(stream.destroy, 10000);
            });   
    }

    // =================== Destroy ===================

    TwitterEventStreamer.prototype.destroy = function () {
        str.destroy();
    }

    // =================== Export ===================

    module.exports = TwitterEventStreamer;
    
