﻿// expose our config directly to our application using module.exports
module.exports = {
    
    'twitterAuth' : {
        'consumerKey'       : '4qEkkaWoWiC9eKgTNDmNcXgZ7',
        'consumerSecret'    : 's45LB5mZ6uzz6oUTmu4BaTSr8q5gPoOyckll85iDAFEnTa3BrH',
        'callbackURL'       : 'http://localhost:3000/auth/twitter/callback'
    }
};